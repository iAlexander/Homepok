<div class="SectionHeader" style="padding-bottom: 20px;">
	<h1 style="border:0px;text-align:center;"><?php echo $sectionHead?></h1>
</div>
