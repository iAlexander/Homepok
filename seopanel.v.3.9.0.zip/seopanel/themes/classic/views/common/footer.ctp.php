<div id="footer">
    <?php echo getRoundTabTop(); ?>
    <div id="round_content_footer">
    	<div><?php echo str_replace('[year]', date('Y'), $spText['common']['copyright'])?></div>
        <div id="powered">
        	<?php echo $spText['common']['Powered by']; ?> <a href="http://www.seopanel.in/" target="_blank" title="Seo Control Panel">Seo Panel</a> (Seo Control Panel)
        </div>
        <?php echo $translatorInfo?>
    </div>
</div>
