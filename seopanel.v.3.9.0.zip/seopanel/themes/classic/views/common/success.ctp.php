<div id='subcontent'>
	<p class='note notesuccess'><?php echo $successMsg;?></p>
</div>