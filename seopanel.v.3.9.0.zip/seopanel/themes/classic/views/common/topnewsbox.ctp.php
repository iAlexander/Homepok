<div id='topnewsbox'>
	<?php echo $newsContent;?>
</div>
<div id="hidenews">
	<a href="javascript:void(0);" onclick="hideNewsBox('newsalert','hidenews','1')"><?php echo $spText['common']['hidenews']?></a>
</div>
