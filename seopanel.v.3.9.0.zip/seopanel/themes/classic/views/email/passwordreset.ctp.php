<?php echo $spText['common']['Hello']?> <?php echo $name?>,<br><br>

<?php echo $spText['login']['Username']; ?>: <?php echo $userName; ?><br><br>
<?php echo $spText['login']['Your account password is resetted and new password is']?>: <?php echo $rand?><br><br>

<a href='<?php echo SP_WEBPATH?>/login.php'><?php echo $spText['label']['Click Here']?></a> <?php echo $spText['login']['to login to your account']?><br><br>

<?php echo $spText['common']['Thank you']; ?>,<br>
Seo Panel Team<br>
<?php echo $spText['common']['Powered by']; ?> <a href="http://www.seopanel.in/">Seo Panel</a>