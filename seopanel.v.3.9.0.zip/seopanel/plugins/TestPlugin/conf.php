<?php
/*
 * plugin specific configuration variables 
 */

define('TEST_HEAD', 'Seo Panel Test Plugin');

define('TEST_SET_HEAD', 'Test Plugin Settings');

?>