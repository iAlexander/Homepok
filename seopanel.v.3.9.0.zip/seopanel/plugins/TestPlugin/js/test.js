function testPlugin(){
	alert('You are using Test Plugin');
}